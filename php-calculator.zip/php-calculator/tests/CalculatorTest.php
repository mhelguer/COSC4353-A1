<?php

use PHPUnit\Framework\TestCase;

class CalculatorTest extends TestCase{
    public function testAdd(){
        $calculator = new App\Calculator;
        $result = $calculator->add(25, 5);

        $this->assertEquals($result, 30);
    }
    
    public function testSubtract(){
        $calculator = new App\Calculator;
        $result = $calculator->subtract(25, 5);

        $this->assertEquals($result, 20);

        
    }

    public function testCheck(){
        $calculator = new App\Calculator;
        $result = $calculator->check();
        $this->assertEquals($result, true);
    }
}
